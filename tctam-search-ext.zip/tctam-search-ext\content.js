document.documentElement.setAttribute('data-tctam-search-extension-installed', 'true');
